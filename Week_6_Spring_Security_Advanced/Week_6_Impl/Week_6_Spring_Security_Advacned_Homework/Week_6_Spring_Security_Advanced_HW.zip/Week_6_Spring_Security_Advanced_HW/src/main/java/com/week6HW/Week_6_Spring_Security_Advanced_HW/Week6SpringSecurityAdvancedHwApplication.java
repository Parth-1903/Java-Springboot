package com.week6HW.Week_6_Spring_Security_Advanced_HW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week6SpringSecurityAdvancedHwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week6SpringSecurityAdvancedHwApplication.class, args);
	}

}
