package com.week6HW.Week_6_Spring_Security_Advanced_HW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week6SpringSecurityAdvancedHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
