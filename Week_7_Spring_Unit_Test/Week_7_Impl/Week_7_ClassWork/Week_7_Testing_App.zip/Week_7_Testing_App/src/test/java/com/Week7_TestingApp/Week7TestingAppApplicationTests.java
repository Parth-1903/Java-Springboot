package com.Week7_TestingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week7TestingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
