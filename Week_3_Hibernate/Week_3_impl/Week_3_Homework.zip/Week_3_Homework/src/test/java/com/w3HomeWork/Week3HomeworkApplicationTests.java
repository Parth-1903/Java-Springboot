package com.w3HomeWork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3HomeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
